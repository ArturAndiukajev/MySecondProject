var firstlib_8cpp =
[
    [ "generavimas", "firstlib_8cpp.html#acf012524f665e401675d308abd9e4acf", null ],
    [ "isvedimas", "firstlib_8cpp.html#a70093a4b53e9020156166e7e9019f356", null ],
    [ "Med", "firstlib_8cpp.html#a06223e44f1fb1bb7bdbcb32ef9bbee4f", null ],
    [ "palyginimasPavardes", "firstlib_8cpp.html#a99691c42ac70a6e9c2ed6bad13d5fe8d", null ],
    [ "palyginimasVardai", "firstlib_8cpp.html#a5e4c824543c780d138191eb9a710944b", null ],
    [ "palyginimasVidurkis", "firstlib_8cpp.html#a146b4e9a6fccbe9ca1c2a77d011dfd7d", null ],
    [ "rezMed", "firstlib_8cpp.html#a9221a6c823d79c5a52d41b1904dd3cfc", null ],
    [ "rezultatas", "firstlib_8cpp.html#af267b2df7a957553ac25b4bfcc3951a8", null ],
    [ "skaitymas", "firstlib_8cpp.html#ab7629c9aad4598c892256091510ffc5b", null ],
    [ "Vargsiukai", "firstlib_8cpp.html#a69cca2cb1966892ec2316d89ccb44f75", null ]
];