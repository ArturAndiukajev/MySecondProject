var class_zmogus =
[
    [ "Zmogus", "class_zmogus.html#ac7034e8672e7feda0e3e1303a5336f2b", null ],
    [ "Zmogus", "class_zmogus.html#a9d2bbeaf83ead87dbb686ee04999885f", null ],
    [ "~Zmogus", "class_zmogus.html#a6183937c7da8254430a6c99cfa89fe69", null ],
    [ "getPavarde", "class_zmogus.html#aca338975f28b0cfe9c66520339b042c0", null ],
    [ "getVardas", "class_zmogus.html#a82e05fb49136546e6e067ed49a4144a9", null ],
    [ "pureVirtualFunction", "class_zmogus.html#a42a0e0cd26280b3d2e1cccf02cbf3c13", null ],
    [ "setPavarde", "class_zmogus.html#a8e44c8c2d9f7880b38e39518ae4c38d4", null ],
    [ "setVardas", "class_zmogus.html#a5807635010cdb68486fa9126a291eeb9", null ],
    [ "pavarde", "class_zmogus.html#a00799e1396c82e4f6dffa0edec1f24e5", null ],
    [ "vardas", "class_zmogus.html#a56da52b45c537a31d2c1fc3a53a73c65", null ]
];