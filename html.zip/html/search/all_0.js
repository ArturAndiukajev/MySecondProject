var searchData=
[
  ['addnd_0',['addND',['../class_studentas.html#a10045447c99600c5506cc7e38213c61d',1,'Studentas']]]
];
