var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#a56da52b45c537a31d2c1fc3a53a73c65',1,'Zmogus']]],
  ['vargsiukai_1',['vargsiukai',['../firstlib_8cpp.html#a69cca2cb1966892ec2316d89ccb44f75',1,'Vargsiukai(const Studentas &amp;studentas, double riba):&#160;firstlib.cpp'],['../firstlib_8h.html#a69cca2cb1966892ec2316d89ccb44f75',1,'Vargsiukai(const Studentas &amp;studentas, double riba):&#160;firstlib.cpp']]]
];
