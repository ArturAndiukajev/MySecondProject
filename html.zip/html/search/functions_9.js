var searchData=
[
  ['zmogus_0',['zmogus',['../class_zmogus.html#ac7034e8672e7feda0e3e1303a5336f2b',1,'Zmogus::Zmogus(const string &amp;vardas, const string &amp;pavarde)'],['../class_zmogus.html#a9d2bbeaf83ead87dbb686ee04999885f',1,'Zmogus::Zmogus(const Zmogus &amp;other)']]]
];
