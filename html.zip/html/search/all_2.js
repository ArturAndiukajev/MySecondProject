var searchData=
[
  ['generavimas_0',['generavimas',['../firstlib_8cpp.html#acf012524f665e401675d308abd9e4acf',1,'generavimas(int studentu_skaicius, string fileName, int nd_kiekis):&#160;firstlib.cpp'],['../firstlib_8h.html#acf012524f665e401675d308abd9e4acf',1,'generavimas(int studentu_skaicius, string fileName, int nd_kiekis):&#160;firstlib.cpp']]],
  ['getegz_1',['getEgz',['../class_studentas.html#a2f9dcb2fef2e6b3dbc1581779a90a68a',1,'Studentas']]],
  ['getgalutinis_2',['getGalutinis',['../class_studentas.html#adff52a10ba657a5c8854693988082820',1,'Studentas']]],
  ['getgalutinismediana_3',['getGalutinisMediana',['../class_studentas.html#ae90de68cf382234281c42f849e24f796',1,'Studentas']]],
  ['getnd_4',['getND',['../class_studentas.html#a43a8cf28f28a5dd719e280d2bc4afeb3',1,'Studentas']]],
  ['getpavarde_5',['getpavarde',['../class_zmogus.html#aca338975f28b0cfe9c66520339b042c0',1,'Zmogus::getPavarde()'],['../class_studentas.html#a5dd7dab43d87cee10ce8b65851adb046',1,'Studentas::getPavarde()']]],
  ['getvardas_6',['getvardas',['../class_zmogus.html#a82e05fb49136546e6e067ed49a4144a9',1,'Zmogus::getVardas()'],['../class_studentas.html#a7658f22795330130632ac24769a2fd43',1,'Studentas::getVardas()']]]
];
