var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#a56da52b45c537a31d2c1fc3a53a73c65',1,'Zmogus']]]
];
