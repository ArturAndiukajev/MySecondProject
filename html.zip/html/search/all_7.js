var searchData=
[
  ['readstudent_0',['readStudent',['../class_studentas.html#a35dc9466153153095ad358d44f3a0387',1,'Studentas']]],
  ['rezmed_1',['rezmed',['../class_studentas.html#ada26492e9ace0e7ba8d7420d4c0e84f4',1,'Studentas::rezMed()'],['../firstlib_8cpp.html#a9221a6c823d79c5a52d41b1904dd3cfc',1,'rezMed(double mediana, int egz):&#160;firstlib.cpp'],['../firstlib_8h.html#a9221a6c823d79c5a52d41b1904dd3cfc',1,'rezMed(double mediana, int egz):&#160;firstlib.cpp']]],
  ['rezultatas_2',['rezultatas',['../class_studentas.html#aec31a8e902ae747edaf0db77a10b881c',1,'Studentas::rezultatas()'],['../firstlib_8cpp.html#af267b2df7a957553ac25b4bfcc3951a8',1,'rezultatas(double suma, int kiekis, int egz):&#160;firstlib.cpp'],['../firstlib_8h.html#af267b2df7a957553ac25b4bfcc3951a8',1,'rezultatas(double suma, int kiekis, int egz):&#160;firstlib.cpp']]]
];
