var searchData=
[
  ['setegzaminas_0',['setEgzaminas',['../class_studentas.html#ae2a4a822427c6bed934900f2c123fcf4',1,'Studentas']]],
  ['setgalutinis_1',['setGalutinis',['../class_studentas.html#a7120afbe2f71881e922aaa65e9192636',1,'Studentas']]],
  ['setgalutinismediana_2',['setGalutinisMediana',['../class_studentas.html#add69155dc65f458cb58e58d969fca221',1,'Studentas']]],
  ['setpavarde_3',['setpavarde',['../class_zmogus.html#a8e44c8c2d9f7880b38e39518ae4c38d4',1,'Zmogus::setPavarde()'],['../class_studentas.html#a468734f362bb3e6480ca88a6be25a6ba',1,'Studentas::setPavarde()']]],
  ['setvardas_4',['setvardas',['../class_zmogus.html#a5807635010cdb68486fa9126a291eeb9',1,'Zmogus::setVardas()'],['../class_studentas.html#a02a2432f782bf1eb460f6d196de4e230',1,'Studentas::setVardas()']]],
  ['skaitymas_5',['skaitymas',['../firstlib_8cpp.html#ab7629c9aad4598c892256091510ffc5b',1,'skaitymas(vector&lt; Studentas &gt; &amp;studentai, string Fname):&#160;firstlib.cpp'],['../firstlib_8h.html#ab7629c9aad4598c892256091510ffc5b',1,'skaitymas(vector&lt; Studentas &gt; &amp;studentai, string Fname):&#160;firstlib.cpp']]],
  ['studentas_6',['studentas',['../class_studentas.html#ab65ef37724c227743c0125a997763e37',1,'Studentas::Studentas(const string &amp;vardas, const string &amp;pavarde, const vector&lt; int &gt; &amp;ND, int Egz)'],['../class_studentas.html#ac77218d8cb02b1259ec679e6dfab304c',1,'Studentas::Studentas(istream &amp;is)'],['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#aef0484fe46cf05746f8ffc0d083fcf3e',1,'Studentas::Studentas(const Studentas &amp;other)']]]
];
