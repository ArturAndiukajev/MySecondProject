var files_dup =
[
    [ "firstlib.cpp", "firstlib_8cpp.html", "firstlib_8cpp" ],
    [ "firstlib.h", "firstlib_8h.html", "firstlib_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];